#include<stdio.h>

int main()

{
	char n;


	scanf ("%c" , &n);

	if (n>='k' && n<='o')
	{
		 printf("It's in between");
	}

	else {
		printf("It's not");
	}

return 0;

}
