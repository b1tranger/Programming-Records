#include <stdio.h>


int main()
{
    printf("This year, the college is celebrating its 75th birthday. Happy birthday, Notre Dame College.");
    return 0;
}

