#include <stdio.h>
int main()
{
   int x = 2, y =3;


   x++; //x=x+1
   printf("%d\n",x);

   x=2;
   x=x++; // takes current value of x into x
   printf("%d\n",x);

   x=2;
   x=++x;
   printf("%d\n",x);

    return 0;
}
