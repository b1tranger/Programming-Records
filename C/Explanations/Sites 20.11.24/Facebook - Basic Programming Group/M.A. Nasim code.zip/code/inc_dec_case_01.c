#include <stdio.h>
int main()
{
   int x = 2, y =3;
   z=y--+c;
   printf("%d\n%d\n%d",z,y,c);
//Z = (Y--) + c;
//Y is post-decremented, so Z will be the current value of Y (which is 12) plus c, which is 7. Therefore, Z = 12 + 7 = 19. After this, Y will become 11.

    return 0;
}
