#include <stdio.h>
int main()
{
   int x = 2, y =3;


   printf("%d",x++ + x++);



    return 0;
}
