#include <stdio.h>
int main()
{
   int x = 1, y =3;


   printf("%d",x-- * ++x);



    return 0;
}
