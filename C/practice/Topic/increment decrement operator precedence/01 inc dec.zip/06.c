#include <stdio.h>
int main()
{
    int x = 2;
    if(x--)
    {
        printf("1");
    }
    if(x--)
    {
        printf("2");
    }
    if(x--)
    {
        printf("3");
    }
    else
    {
        printf("None");
    }
    printf("-1");
    return 0;
}
