#include <stdio.h>
int main()
{
    int a = 5, b = 3, c=2;
    printf("%d\n",a++);
    printf("%d\n",a);
    return 0;
}
