#include <stdio.h>
int main()
{
    int x=2,n=2;
    x=n++;
    printf("%d\n",x);
    x=++n;
    printf("%d\n",x);
    printf("%d\n",n);
    return 0;
}
