#include <stdio.h>
int main()
{
    int x = 1;
    if(x--)
    {
        printf("Hello");
    }
    if(x++)
    {
        printf("Evewryone");
    }
    return 0;
}
