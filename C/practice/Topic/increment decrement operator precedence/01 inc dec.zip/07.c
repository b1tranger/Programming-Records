#include <stdio.h>
int main()
{
    int x =3;
    if(--x)
        printf("%d",x);
    if(--x)
        printf("%d",x);
    if(--x)
        printf("%d",x);
    else if(x--)
        printf("%d",x);
    else
        printf("%d",x);
    printf("%d",x);
    return 0;
}
