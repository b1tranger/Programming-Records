#include <stdio.h>
int main()
{
    int x=2, y = 3;
    printf("%d\n",x);
    x*=y;
    printf("%d\n",x);
    x=x*y;
    printf("%d\n",x);
    x*=y+1;
    printf("%d",x);
    return 0;
}
