#include<stdio.h>

int main()
{
    int N;
    scanf("%d",&N); //number of test cases




    return 0;
}
