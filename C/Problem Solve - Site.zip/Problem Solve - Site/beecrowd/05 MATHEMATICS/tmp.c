#include <stdio.h>

in main()
{


    return 0;
}
