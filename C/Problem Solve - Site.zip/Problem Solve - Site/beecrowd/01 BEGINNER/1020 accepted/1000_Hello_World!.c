#include <stdio.h>

int main() {
  printf("\n\n\n\n\nHello World!\n\n\n\n\n");
  return 0;
}

/*Welcome to beecrowd!

Your first program in any programming language is usually "Hello World!". In this first problem all you have to do is print this message on the screen.

Input
This problem has no input.

Output
You must print the message Hello World! and then the endline as shown below.*/