public class LinkedListDriver {
    public static void main(String[] args) {
        LinkedList list = new LinkedList();

        // Creating a linked list from an array
        int[] elements = {1, 2, 3, 4, 5};
        list.createList(elements);
        System.out.println("Original Linked List:");
        list.printLL(list.head);

        // Appending an element
        list.appendLL(6);
        System.out.println("After appending 6:");
        list.printLL(list.head);

        // Prepending an element
        list.prependLL(0);
        System.out.println("After prepending 0:");
        list.printLL(list.head);

        // Getting the size of the linked list
        System.out.println("Size of the linked list: " + list.get_size());

        // Checking if a value exists in the list
        System.out.println("Contains 3? " + list.contains(3));
        System.out.println("Contains 10? " + list.contains(10));

        // Getting an element at a specific index
        System.out.println("Element at index 3: " + list.getElem(3));

        // Finding the index of a specific value
        System.out.println("Index of element 4: " + list.indexOf(4));

        // Setting a node value
        list.setNode1(2, 10);
        System.out.println("After updating index 2 to 10:");
        list.printLL(list.head);

        // Inserting at a specific index
        list.insertAt(3, 99);
        System.out.println("After inserting 99 at index 3:");
        list.printLL(list.head);

        // Removing a node at a specific index
        list.removeAt(4);
        System.out.println("After removing element at index 4:");
        list.printLL(list.head);

        // Copying the linked list
        LinkedList.Node copiedListHead = list.copyList();
        System.out.println("Copied linked list:");
        list.printLL(copiedListHead);

        // Reversing the list out of place
        LinkedList.Node reversedList = list.reverseOutOfPlace();
        System.out.println("Reversed (out of place) linked list:");
        list.printLL(reversedList);

        // Reversing the list in place
        list.head = list.reverseInPlace();
        System.out.println("Reversed (in place) linked list:");
        list.printLL(list.head);

        // Rotating left
        list.rotateLeft();
        System.out.println("After rotating left:");
        list.printLL(list.head);
        
        System.out.println("Rotation left by 2 positions:");
        list.rotateLeftMul(2);
        list.printLL(list.head);

        System.out.println("Rotation left by 1 position:");
        list.rotateLeftMul(1);
        list.printLL(list.head);

        // Rotating right
        list.rotateRight();
        System.out.println("After rotating right:");
        list.printLL(list.head);
        
        System.out.println("Rotation right by 2 positions:");
        list.rotateRightMul(2);
        list.printLL(list.head);

        System.out.println("Rotation right by 1 position:");
        list.rotateRightMul(1);
        list.printLL(list.head);
    }
}
