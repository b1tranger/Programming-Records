class DNode {
    int elem;
    DNode next, prev;
    
    public DNode(int elem) {
        this.elem = elem;
        this.next = this.prev = null;
    }
}


