
class QueueDHCLL {
    private DNode head;
    private int size;
    
    public QueueDHCLL() {
        head = new DNode(-1); // Dummy head node
        head.next = head.prev = head; // Circular reference
        size = 0;
    }
    
    public boolean isEmpty() {
        return size == 0;
    }
    
    public int size() {
        return size;
    }
    
    public void enqueue(int elem) {
        DNode newNode = new DNode(elem);
        DNode rear = head.prev;
        
        newNode.prev = rear;
        newNode.next = head;
        
        rear.next = newNode;
        head.prev = newNode;
        size++;
    }
    
    public int dequeue() {
        if (isEmpty()) throw new RuntimeException("Underflow: Queue is empty");
        
        DNode remNode = head.next;
        head.next = remNode.next;
        remNode.next.prev = head;
        
        size--;
        return remNode.elem;
    }
    
    public int peek() {
        if (isEmpty()) throw new RuntimeException("Queue is empty");
        return head.next.elem;
    }
    
    public String toString() {
        if (isEmpty()) return "[]";
        StringBuilder sb = new StringBuilder("[");
        DNode current = head.next;
        while (current != head) {
            sb.append(current.elem).append(" ");
            current = current.next;
        }
        return sb.toString().trim() + "]";
    }
    
    public int[] toArray() {
        int[] arr = new int[size];
        DNode current = head.next;
        for (int i = 0; i < size; i++) {
            arr[i] = current.elem;
            current = current.next;
        }
        return arr;
    }
    
    public int search(int obj) {
        DNode current = head.next;
        int index = 0;
        while (current != head) {
            if (current.elem == obj) return index;
            current = current.next;
            index++;
        }
        return -1;
    }
    
    public void displayQueue() {
        DNode current = head.next;
        System.out.print("Queue (front to rear): ");
        while (current != head) {
            System.out.print(current.elem + " <-> ");
            current = current.next;
        }
        System.out.println("NULL");
    }
}