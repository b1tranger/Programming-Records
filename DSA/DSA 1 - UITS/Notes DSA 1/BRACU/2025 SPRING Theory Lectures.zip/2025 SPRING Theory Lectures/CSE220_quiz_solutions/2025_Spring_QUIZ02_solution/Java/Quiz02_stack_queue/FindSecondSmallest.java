public class FindSecondSmallest {

    public static Integer findSecondSmallest(QuizStack stack) {
        if (stack.isEmpty()) {
            return null; // Edge case (though the problem assumes at least 2 elements)
        }

        Integer smallest = null;
        Integer secondSmallest = null;

        // Temporary stack to store elements while traversing
        QuizStack tempStack = new QuizStack();

        // Traverse through the stack
        while (!stack.isEmpty()) {
            int value = stack.pop();

            // Update smallest and second smallest
            if (smallest == null || value < smallest) {
                secondSmallest = smallest;
                smallest = value;
            } else if (secondSmallest == null || value < secondSmallest) {
                secondSmallest = value;
            }
        }

        return secondSmallest;
    }

    public static void main(String[] args) {
        // Test Case 1
        QuizStack quizStack = new QuizStack();
        int[] numbers1 = {3, 5, 2, 1, -5, 10};
        for (int num : numbers1) {
            quizStack.push(num);
        }
        System.out.println(findSecondSmallest(quizStack));  // Output: 2

        // Test Case 2
        quizStack = new QuizStack();
        int[] numbers2 = {7, 10, 5, 15, 40, -3, 30, 10};
        for (int num : numbers2) {
            quizStack.push(num);
        }
        System.out.println(findSecondSmallest(quizStack));  // Output: 5
    }
}