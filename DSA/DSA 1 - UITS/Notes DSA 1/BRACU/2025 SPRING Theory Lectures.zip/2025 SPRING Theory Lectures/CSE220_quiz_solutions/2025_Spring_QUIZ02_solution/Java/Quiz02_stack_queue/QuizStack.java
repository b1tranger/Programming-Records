class QuizStack {
    private Node top;
    private int size;

    public QuizStack() {
        this.top = null;
        this.size = 0;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public void push(int data) {
        Node newNode = new Node(data);
        newNode.next = top;
        top = newNode;
        size++;
    }

    public Integer pop() {
        if (isEmpty()) {
            return null;
        }
        int poppedData = top.data;
        top = top.next;
        size--;
        return poppedData;
    }

    public Integer peek() {
        if (isEmpty()) {
            return null;
        }
        return top.data;
    }
}