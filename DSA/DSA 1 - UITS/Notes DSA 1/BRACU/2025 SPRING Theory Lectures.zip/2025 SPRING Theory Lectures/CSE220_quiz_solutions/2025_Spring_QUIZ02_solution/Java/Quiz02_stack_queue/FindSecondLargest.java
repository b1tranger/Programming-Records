public class FindSecondLargest{
    public static Integer findSecondLargest(QuizStack stack) {
        if (stack.isEmpty()) {
            return null; // Edge case (though the problem assumes at least 2 elements)
        }

        Integer largest = null;
        Integer secondLargest = null;

        // Temporary stack to store elements while traversing
        QuizStack tempStack = new QuizStack();

        // Traverse through the stack
        while (!stack.isEmpty()) {
            int value = stack.pop();

            // Update largest and second largest
            if (largest == null || value > largest) {
                secondLargest = largest;
                largest = value;
            } else if (secondLargest == null || value > secondLargest) {
                secondLargest = value;
            }

        }

        return secondLargest;
    }

    public static void main(String[] args) {
        QuizStack quizStack = new QuizStack();
        int[] numbers = {7, 10, 5, 5, 40, -3, 30, 10};
        for (int num : numbers) {
            quizStack.push(num);
        }
        System.out.println(findSecondLargest(quizStack));  // Output: 30

        quizStack = new QuizStack();
        int[] numbers2 = {3, 5, 2, 1, -5, 1};
        for (int num : numbers2) {
            quizStack.push(num);
        }
        System.out.println(findSecondLargest(quizStack));  // Output: 3
    }
}