class Node {
    int elem;
    Node next;

    public Node(int elem) {
        this.elem = elem;
        this.next = null;
    }
}

public class LinkedListMerger2 {
    public static String LLMerger(Node L1, Node L2) {
        String result = ""; // Using String instead of StringBuilder
        int index = 0;
        
        while (getNode(L1, index) != null && getNode(L2, index) != null) {
            result += getNode(L1, index).elem + "" + getNode(L2, index).elem; 
            index++;
        }

        // Find the longer list
        Node longerList = L1;
        if (getNode(L2, index) != null) {
            longerList = L2;
        }

        // Append remaining elements
        while (getNode(longerList, index) != null) {
            result += getNode(longerList, index).elem;
            index++;
        }

        return result;
    }

    public static Node getNode(Node head, int index) {
        Node current = head;
        int count = 0;
        while (current != null) {
            if (count == index) return current;
            current = current.next;
            count++;
        }
        return null;
    }

    public static Node createList(int[] arr) {
        if (arr.length == 0) return null;
        Node head = new Node(arr[0]);
        Node tail = head;
        for (int i = 1; i < arr.length; i++) {
            tail.next = new Node(arr[i]);
            tail = tail.next;
        }
        return head;
    }

    public static void main(String[] args) {
        Node L1 = createList(new int[]{1, 3, 5});
        Node L2 = createList(new int[]{2, 4, 6, 7});
        System.out.println("Returned value: " + LLMerger(L1, L2)); // Output: "1234567"

        Node L3 = createList(new int[]{8, 16, 24, 32, 5, 9});
        Node L4 = createList(new int[]{7, 14, 21});
        System.out.println("Returned value: " + LLMerger(L3, L4)); // Output: "87161424213259"
    }
}
