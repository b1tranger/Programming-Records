class Node {
    int elem;
    Node next;

    public Node(int elem) {
        this.elem = elem;
        this.next = null;
    }
}

public class LinkedListMerger {

    public static String LLMerger(Node L1, Node L2) {
        String result = "";  // Initialize an empty string to store the result
        
        Node p1 = L1;
        Node p2 = L2;
        
        // Merge alternating elements from both lists
        while (p1 != null && p2 != null) {
            result += p1.elem;  // Add element from L1
            p1 = p1.next;
            result += p2.elem;  // Add element from L2
            p2 = p2.next;
        }
        
        // Append remaining elements from the larger list
        while (p1 != null) {
            result += p1.elem;
            p1 = p1.next;
        }
        
        while (p2 != null) {
            result += p2.elem;
            p2 = p2.next;
        }
        
        return result;
    }

    // Helper method to create a linked list from an array
    public static Node createList(int[] arr) {
        if (arr.length == 0) {
            return null;
        }
        
        Node head = new Node(arr[0]);
        Node tail = head;
        
        for (int i = 1; i < arr.length; i++) {
            tail.next = new Node(arr[i]);
            tail = tail.next;
        }
        
        return head;
    }

    public static void main(String[] args) {
        // Example usage:
        Node L1 = createList(new int[]{1, 3, 5});
        Node L2 = createList(new int[]{2, 4, 6, 7});
        
        String result = LLMerger(L1, L2);
        System.out.println(result);  // Output: "1234567"
        
        Node L11 = createList(new int[]{8, 16, 24, 32, 5, 9});
        Node L22 = createList(new int[]{7, 14, 21});
        
        String result2 = LLMerger(L11, L22);
        System.out.println(result2);  // Output: "87161424213259"
    }
}
