class HashTableExampleType2 {
    private int size;
    private Node[] table;

    public HashTableExampleType2(int size) {
        this.size = size;
        this.table = new Node[size]; // Initialize hash table
    }

    private int hashFunction(String key) {
        int hashValue = 0;
        for (int i = 0; i < key.length(); i++) {
            hashValue += key.charAt(i);
        }
        return hashValue % size;
    }

    public void insert(String key, int value) {
        int index = hashFunction(key);

        if (table[index] == null) {
            table[index] = new Node(null, -1); // Dummy head node, key is null, value is -1
        }

        // Prepend after dummy head
        Node newNode = new Node(key, value);
        Node predecessor = table[index]; // Predecessor is dummy head
        Node successor = predecessor.next;

        newNode.next = successor; // Link the successor
        predecessor.next = newNode; // Link the predecessor
    }

    public boolean search(String key) {
        /** Search for a key in the hash table. */
        int index = hashFunction(key);
        Node current = table[index].next; // Starting after dummy head
    
        while (current != null) { // Going till tail
            if (current.key == key) {  // If key matches, return true
                return true;
            }
            current = current.next;  // Move to the next node
        }
    
        return false;  // If the key is not found
    }


    
    public void remove(String remKey) {
        int index = hashFunction(remKey);

        // Start at the dummy head
        if (table[index] == null) {
            System.out.println("Key '" + remKey + "' not found.");
            return;
        }

        Node predecessor = table[index]; // Predecessor (head node), i = 0
        Node remNode = predecessor.next; // Node to be removed (remNode), j = i+1

        
        while (remNode != null) {
            if (remNode.key.equals(remKey)) { // Found the node to remove
                Node successor = remNode.next; // The node after remNode
                predecessor.next = successor; // Bypass remNode
                System.out.println("Removed (" + remNode.key + ", " + remNode.value + ")");
                return;
            }
            predecessor = remNode; // Move predecessor forward, i++
            remNode = remNode.next; // Move remNode forward, j++
        }

        System.out.println("Key '" + remKey + "' not found.");
    }


    public void printHashTable() {
        for (int i = 0; i < size; i++) {
            System.out.print(i + ": ");
            Node current = table[i];
            while (current != null && current.next != null) {
                System.out.print("(" + current.next.key + ", " + current.next.value + ") → ");
                current = current.next;
            }
            System.out.println("None");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        HashTableExampleType2 hashTable = new HashTableExampleType2(5);

        System.out.println("Hash table before insert:");
        System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
        hashTable.printHashTable();

        hashTable.insert("cat", 10);
        hashTable.insert("dog", 20);
        hashTable.insert("rat", 40);
        hashTable.insert("owl", 50);
        hashTable.insert("fox", 60);
        hashTable.insert("ant", 70);
        hashTable.insert("bee", 80);

        System.out.println("Hash table after insert:");
        System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
        hashTable.printHashTable();

        System.out.println("Hash table before search:");
        hashTable.printHashTable();
        System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");

        System.out.println(hashTable.search("rat")); // Output: true
        System.out.println(hashTable.search("owl")); // Output: true
        System.out.println(hashTable.search("hen")); // Output: false

        System.out.println("Hash table after search:");
        System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
        hashTable.printHashTable();

        System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
        System.out.println("Hash table before removals:");
        hashTable.printHashTable();

        hashTable.remove("cat");
        hashTable.remove("owl");
        hashTable.remove("dog");

        System.out.println("\nHash table after removals:");
        System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
        hashTable.printHashTable();
    }
}
