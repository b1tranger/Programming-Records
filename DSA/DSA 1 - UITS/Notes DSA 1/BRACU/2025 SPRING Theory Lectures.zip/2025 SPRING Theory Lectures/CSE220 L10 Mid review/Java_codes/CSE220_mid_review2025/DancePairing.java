// DNode class for Linked List-based DStack and Queue
class DNode {
    String data;
    DNode next;

    public DNode(String data) {
        this.data = data;
        this.next = null;
    }
}

// Linked List-based DStack
class DStack {
    private DNode top;

    public DStack() {
        this.top = null;
    }

    public void push(String data) {
        DNode newDNode = new DNode(data);
        newDNode.next = top;
        top = newDNode;
    }

    public String pop() {
        if (isEmpty()) return null;
        String data = top.data;
        top = top.next;
        return data;
    }

    public String peek() {
        if (isEmpty()){
            return null;
        }
        else{
            return top.data;
        }
    }

    public boolean isEmpty() {
        return top == null;
    }
}

// Linked List-based Queue
class Queue {
    private DNode front, rear;

    public Queue() {
        this.front = this.rear = null;
    }

    public void enq(String data) {
        DNode newDNode = new DNode(data);
        if (rear == null) {
            front = rear = newDNode;
            return;
        }
        rear.next = newDNode;
        rear = newDNode;
    }

    public String deq() {
        if (isEmpty()) return null;
        String data = front.data;
        front = front.next;
        if (front == null) rear = null;
        return data;
    }

    public String peek() {
        if (isEmpty()){
            return null;
        }
        else{
            return front.data;
        }
    }

    public boolean isEmpty() {
        return front == null;
    }
}

// Main class for Dance Pairing logic
public class DancePairing {
    
    public static void dancePair(DStack st, Queue femaleQueue) {
        while (!st.isEmpty()) {
            String person = st.pop();
            String[] personInfo = idGenderExtractor(person);
            String gender = personInfo[0];
            String id = personInfo[1];

            if (gender.equals("M")) {
                // If male, check if female is directly below in DStack
                if (!st.isEmpty()) {
                    String nextPerson = st.peek();
                    String[] nextInfo = idGenderExtractor(nextPerson);
                    String nextGender = nextInfo[0];
                    String nextId = nextInfo[1];

                    if (nextGender.equals("F")) {
                        st.pop(); // Remove female from DStack
                        System.out.println(id + " and " + nextId + " are paired together");
                    } else {
                        // If no female below, try pairing from queue
                        if (!femaleQueue.isEmpty()) {
                            String female = femaleQueue.deq();
                            String[] femaleInfo = idGenderExtractor(female);
                            System.out.println(femaleInfo[1] + " and " + id + " are paired together");
                        }
                    }
                } else {
                    // If male is last in DStack, try pairing with queue
                    if (!femaleQueue.isEmpty()) {
                        String female = femaleQueue.deq();
                        String[] femaleInfo = idGenderExtractor(female);
                        System.out.println(femaleInfo[1] + " and " + id + " are paired together");
                    }
                }
            } else { // Female case
                // If a male is immediately below in the DStack
                if (!st.isEmpty()) {
                    String nextPerson = st.peek();
                    String[] nextInfo = idGenderExtractor(nextPerson);
                    String nextGender = nextInfo[0];
                    String nextId = nextInfo[1];

                    if (nextGender.equals("M")) {
                        st.pop(); // Remove male from DStack
                        System.out.println(id + " and " + nextId + " are paired together");
                    } else {
                        // No male below, store female in queue
                        femaleQueue.enq(person);
                    }
                } else {
                    // If last element is a female, store in queue
                    femaleQueue.enq(person);
                }
            }
        }
    }

    // Helper function to extract gender and ID
    public static String[] idGenderExtractor(String s) {
        if (s != null) {
            return new String[]{s.substring(0, 1), s.substring(2)};
        }
        return new String[]{"", ""};
    }

    public static void main(String[] args) {
        DStack st = new DStack();
        Queue femaleQueue = new Queue();

        st.push("F_18");
        st.push("F_9");
        st.push("M_7");
        st.push("M_1");
        st.push("M_19");
        st.push("M_3");
        st.push("F_5");
        st.push("F_4");
        st.push("F_20");
        st.push("M_10");

        System.out.println("Pairing dancers:");
        dancePair(st, femaleQueue);
    }
}
