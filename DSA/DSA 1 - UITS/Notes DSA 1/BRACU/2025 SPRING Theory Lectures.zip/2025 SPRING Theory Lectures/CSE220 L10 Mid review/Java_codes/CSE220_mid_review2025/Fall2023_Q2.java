class Node {
    int value;
    Node next;

    // Constructor to initialize the node
    public Node(int value) {
        this.value = value;
        this.next = null;
    }
}

public class Fall2023_Q2 {

    // Helper function to create a linked list from an array of elements
    public static Node createLinkedList(int[] elements) {
        if (elements.length == 0) {
            return null;
        }
        Node head = new Node(elements[0]);
        Node current = head;
        for (int i = 1; i < elements.length; i++) {
            current.next = new Node(elements[i]);
            current = current.next;
        }
        return head;
    }

    // Function to print the linked list
    public static void printLinkedList(Node head) {
        Node current = head;
        while (current != null) {
            if (current.next != null) {
                System.out.print(current.value + " -> ");
            } else {
                System.out.print(current.value);
            }
            current = current.next;
        }
        System.out.println();
    }

    // Function to check if two linked lists have equal pairs
    public static boolean pairwiseEqual(Node head1, Node head2) {
        // Traverse both linked lists
        while (head1 != null && head2 != null && head1.next != null && head2.next != null) {
            // Get the current and next values from both lists
            int L1_elem1 = head1.value;
            int L1_elem2 = head1.next.value;

            int L2_elem1 = head2.value;
            int L2_elem2 = head2.next.value;

            // Check if the pairs are equal irrespective of the order
            if (!((L1_elem1 == L2_elem1 && L1_elem2 == L2_elem2) || (L1_elem1 == L2_elem2 && L1_elem2 == L2_elem1))) {
                return false;
            }

            // Move to the next pair (i = i+2)
            head1 = head1.next.next;
            head2 = head2.next.next;
        }

        // Ensure both lists are fully traversed and of the same length
        return head1 == null && head2 == null;
    }

    public static void main(String[] args) {
        // Test Case 1: Create linked lists and check if pairs are equal
        int[] elements1 = {10, 15, 34, 41};
        Node head1 = createLinkedList(elements1);

        int[] elements2 = {15, 10, 34, 41};
        Node head2 = createLinkedList(elements2);

        System.out.println("Test Case 1:");
        System.out.println(pairwiseEqual(head1, head2));  // Expected output: true

        // Test Case 2: Create linked lists with different elements and check if pairs are equal
        int[] elements3 = {10, 15, 34, 42};
        head1 = createLinkedList(elements3);

        int[] elements4 = {10, 15, 34, 41};
        head2 = createLinkedList(elements4);

        System.out.println("Test Case 2:");
        System.out.println(pairwiseEqual(head1, head2));  // Expected output: false
    }
}
