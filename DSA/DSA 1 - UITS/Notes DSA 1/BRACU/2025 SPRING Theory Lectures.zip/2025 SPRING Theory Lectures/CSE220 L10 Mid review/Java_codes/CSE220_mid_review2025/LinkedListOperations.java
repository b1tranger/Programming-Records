class Node {
    int elem;
    Node next;

    // Constructor to initialize a node
    public Node(int elem, Node next) {
        this.elem = elem;
        this.next = next;
    }
}

public class LinkedListOperations {

    // Function to create a linked list from an array
    public static Node createList(int[] arr) {
        Node head = new Node(arr[0], null);
        Node tail = head;
        for (int i = 1; i < arr.length; i++) {
            Node newNode = new Node(arr[i], null);
            tail.next = newNode;
            tail = newNode;
        }
        return head;
    }

    // Function to print the linked list
    public static void printLinkedList(Node head) {
        Node temp = head;
        while (temp != null) {
            if (temp.next != null) {
                System.out.print(temp.elem + "-->");
            } else {
                System.out.print(temp.elem);
            }
            temp = temp.next;
        }
        System.out.println();
    }

    // Function to get the node at the ith index
    public static Node nodeAt(Node head, int idx) {
        Node temp = head;
        for (int i = 0; i < idx; i++) {
            temp = temp.next;
        }
        return temp;
    }

    // Function to reverse the linked list
    public static Node reverse(Node head) {
        Node newHead = null;
        Node curr = head;
        while (curr != null) {
            Node next = curr.next;
            curr.next = newHead;
            newHead = curr;
            curr = next;
        }
        return newHead;
    }

    // Function to reverse the first part and swap the rest
    public static Node reverseAndSwap(Node head, int i) {
        // Separate into two parts correctly
        Node ithNode = nodeAt(head, i);
        Node partB = ithNode.next;
        ithNode.next = null;
        Node partA = head;

        // Reverse the first part
        Node partAReversed = reverse(partA);

        // New head is the start of part B
        Node newHead = partB;

        // If part B is not null, connect it to the reversed part A
        if (partB != null) {
            while (partB.next != null) {
                partB = partB.next;
            }
            partB.next = partAReversed;
            return newHead;
        } else { // If part B is null, just return the reversed part A
            return partAReversed;
        }
    }
    
    
        // Function to reverse and swap the first `i+1` nodes of the list
    public static Node reverseAndSwap2(Node head, int i) {
        if (head == null || i < 0) {  // No reverse needed
            return head;
        }

        // Step 1: Reverse the first `i+1` nodes
        Node prev = null;
        Node current = head;
        int count = 0;
        while (current != null && count <= i) {
            Node nextNode = current.next;
            current.next = prev;
            prev = current;
            current = nextNode;
            count++;
        }

        // Now `prev` is the new head of the reversed part, `current` is the head of the unchanged part
        Node reversedHead = prev;
        Node reversedTail = head;
        Node unchangedHead = current;

        // Step 2: Find the tail of the unchanged part
        Node unchangedTail = unchangedHead;
        while (unchangedTail != null && unchangedTail.next != null) {
            unchangedTail = unchangedTail.next;
        }

        // Step 3: Combine the unchanged part before the reversed part
        if (unchangedTail != null) {
            unchangedTail.next = reversedHead;
        } else {
            unchangedHead = reversedHead;  // If no unchanged part exists
        }

        // Step 4: The original head of the reversed part (now the tail of the reversed part) should point to null
        if (reversedTail != null) {
            reversedTail.next = null;
        }

        // The new head is the head of the unchanged part
        return unchangedHead;
    }

    public static void main(String[] args) {
        System.out.println("Type1: Fall 2024: Reverse and swap");
        // Test Case 1
        System.out.println("Test Case 1");
        int[] arr1 = {5, 7, 6, 3, 8, 2, 1};
        Node L1 = createList(arr1);
        printLinkedList(L1);
        L1 = reverseAndSwap(L1, 3);
        printLinkedList(L1);

        System.out.println("###########################");

        // Test Case 2
        System.out.println("Test Case 2");
        int[] arr2 = {5, 7, 6, 3, 8, 2, 1};
        L1 = createList(arr2);
        printLinkedList(L1);
        L1 = reverseAndSwap(L1, 0);
        printLinkedList(L1);

        System.out.println("###########################");

        // Test Case 3
        System.out.println("Test Case 3");
        int[] arr3 = {5, 7, 6, 3, 8, 2, 1};
        L1 = createList(arr3);
        printLinkedList(L1);
        L1 = reverseAndSwap(L1, 6);
        printLinkedList(L1);

        System.out.println("###########################");

        // Test Case 4
        System.out.println("Test Case 4");
        int[] arr4 = {5, 7, 6, 3, 8, 2, 1};
        L1 = createList(arr4);
        printLinkedList(L1);
        L1 = reverseAndSwap(L1, 5);
        printLinkedList(L1);

        System.out.println("###########################");
        
        System.out.println("Type2: Fall 2024: Reverse and swap");
                // Test Cases
        int[] elements = {5, 7, 6, 3, 8, 2, 1};

        // Test Case 1
        System.out.println("Test Case 1:");
        Node head = createList(elements);
        System.out.print("Original List: ");
        printLinkedList(head);
        head = reverseAndSwap2(head, 3);
        System.out.print("Modified List: ");
        printLinkedList(head);

        System.out.println("\n###########################");

        // Test Case 2
        System.out.println("Test Case 2:");
        head = createList(elements);
        System.out.print("Original List: ");
        printLinkedList(head);
        head = reverseAndSwap2(head, 0);
        System.out.print("Modified List: ");
        printLinkedList(head);

        System.out.println("\n###########################");

        // Test Case 3
        System.out.println("Test Case 3:");
        head = createList(elements);
        System.out.print("Original List: ");
        printLinkedList(head);
        head = reverseAndSwap2(head, 6);
        System.out.print("Modified List: ");
        printLinkedList(head);

        System.out.println("\n###########################");

        // Test Case 4
        System.out.println("Test Case 4:");
        head = createList(elements);
        System.out.print("Original List: ");
        printLinkedList(head);
        head = reverseAndSwap2(head, 5);
        System.out.print("Modified List: ");
        printLinkedList(head);

    }
}
