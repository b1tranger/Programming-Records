class Node {
    int value;
    Node next;

    // Constructor to initialize the node
    public Node(int value) {
        this.value = value;
        this.next = null;
    }
}

public class Spring2024_Q2 {

    // Helper function to create a linked list from an array of elements
    public static Node createLinkedList(int[] elements) {
        if (elements.length == 0) {
            return null;
        }
        Node head = new Node(elements[0]);
        Node current = head;
        for (int i = 1; i < elements.length; i++) {
            current.next = new Node(elements[i]);
            current = current.next;
        }
        return head;
    }

    // Function to print the linked list
    public static void printLinkedList(Node head) {
        Node current = head;
        while (current != null) {
            if (current.next != null) {
                System.out.print(current.value + " → ");
            } else {
                System.out.print(current.value);
            }
            current = current.next;
        }
        System.out.println();
    }

    // Function to check if the sum of any two elements in the list equals the given number
    public static boolean isSumPossible(Node head, int givenNum) {
        Node current = head; // i = 0
        while (current != null) {
            // For each node, traverse all subsequent nodes
            Node temp = current.next; // j = i + 1
            while (temp != null) {
                // Check if the sum of current and temp node values equals givenNum
                if (current.value + temp.value == givenNum) {
                    System.out.println(current.value + " + " + temp.value + " = " + givenNum);
                    return true;
                }
                temp = temp.next; // j = j + 1
            }
            current = current.next; // i = i + 1
        }

        // If no pair is found, return false
        return false;
    }

    public static void main(String[] args) {
        // Example 1: Create linked list 1 → 2 → 3 → 4 → 5
        int[] elements1 = {1, 2, 3, 4, 5};
        Node head1 = createLinkedList(elements1);

        // Test the isSumPossible function
        System.out.println(isSumPossible(head1, 7));  // Output: True (3 + 4 = 7 or 2 + 5 = 7)

        // Example 2: Create linked list 1 → 2 → 4 → 5 → 6
        int[] elements2 = {1, 2, 4, 5, 6};
        Node head2 = createLinkedList(elements2);

        System.out.println(isSumPossible(head2, 4));  // Output: False (no two elements sum to 4)

        // Example 3: Create a single node list (5)
        Node head3 = new Node(5);
        System.out.println(isSumPossible(head3, 5));  // Output: False (only one element in the list)
    }
}
