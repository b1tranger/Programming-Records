public class Fall2024_ZigZag {

    // Method to print the zigzag pattern (upper and lower triangles)
    public static void zigZag4(char[][] arr) {
        int rows = arr.length;

        // Upper triangle (first part)
        for (int rowNo = 0; rowNo < rows; rowNo++) {
            for (int colNo = 0; colNo <= rowNo; colNo++) {
                System.out.print(arr[rowNo - colNo][colNo] + " ");
            }
        }

       // System.out.println();

        // Lower triangle (second part)
        for (int colNo = 0; colNo < rows; colNo++) {
            for (int rowNo = rows - 1; rowNo > colNo; rowNo--) {
                System.out.print(arr[rowNo][rows - rowNo + colNo] + " ");
            }
        }
    }

    // Method to print the zigzag pattern (upper left and lower right triangles)
    public static void zigzag2(char[][] arr) {
        int rows = arr.length;      // rows = 4
        int lim = 2 * (rows - 1);   // lim = 6

        // Printing upper left triangle
        int lineNo = 0;
        while (lineNo <= rows - 1) {   // 0 ~ 3
            int rowNo = lineNo;
            int colNo = 0;
            while (colNo <= lineNo) {
                System.out.print(arr[rowNo][colNo] + " ");
                rowNo--;
                colNo++;
            }
            lineNo++;
        }

        //System.out.println();

        // Printing lower right triangle
        while (lineNo <= lim) {       // 4 ~ 6
            int rowNo = rows - 1;
            int colNo = lineNo - rowNo;
            while (colNo <= rows - 1) {
                System.out.print(arr[rowNo][colNo] + " ");
                rowNo--;
                colNo++;
            }
            lineNo++;
        }
    }

    // Main method to test both functions
    public static void main(String[] args) {
        char[][] matrix = {
            {'D', 'B', 'G', 'S'},
            {'A', 'G', 'T', 'S'},
            {'W', 'U', 'R', 'N'},
            {'O', 'H', 'R', 'O'}
        };

        // Test zigZag4 function
        System.out.println("zigZag4 output:");
        zigZag4(matrix);
        System.out.println();
        System.out.println("-".repeat(50));

        // Test zigzag2 function
        System.out.println("zigzag2 output:");
        zigzag2(matrix);
        System.out.println();
    }
}
