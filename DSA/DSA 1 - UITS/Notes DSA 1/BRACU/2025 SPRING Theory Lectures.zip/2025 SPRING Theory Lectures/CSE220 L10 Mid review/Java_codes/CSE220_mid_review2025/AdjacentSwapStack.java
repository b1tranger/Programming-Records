class ANode {
    int data;
    ANode next;

    public ANode(int data) {
        this.data = data;
        this.next = null;
    }
}

class MidStack {
    private ANode top;
    private int size;

    public MidStack() {
        this.top = null;
        this.size = 0;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public void push(int data) {
        ANode newNode = new ANode(data);
        newNode.next = top;  // New node points to the current top
        top = newNode;       // Update the top to the new node
        size++;
    }

    public int pop() {
        if (isEmpty()) {
            throw new IllegalStateException("Underflow: Pop from empty stack");
        }
        int poppedData = top.data;  // Retrieve the data of the top node
        top = top.next;             // Update the top to the next node
        size--;
        return poppedData;
    }

    public int peek() {
        if (isEmpty()) {
            throw new IllegalStateException("Underflow: Peek from empty stack");
        }
        return top.data;
    }
}

public class AdjacentSwapStack {

    public static MidStack doAdjacentSwap(MidStack st) {
        if (st.isEmpty()) {
            return st;
        }

        MidStack revStack = new MidStack();
        MidStack resultStack = new MidStack();

        // Reverse the stack
        int size = 0; // It might not be always accesible--from MidStack class
        while (!st.isEmpty()) {
            revStack.push(st.pop());
            size+=1;
        }

        if (size % 2 == 0) {
            // Even number of elements
            for (int i = 0; i < size / 2; i++) {
                int first = revStack.pop();
                int second = revStack.pop();
                resultStack.push(second);
                resultStack.push(first);
            }
        } else {
            // Odd number of elements
            resultStack.push(revStack.pop());  // Push the last odd element
            for (int i = 0; i < (size - 1) / 2; i++) {
                int first = revStack.pop();
                int second = revStack.pop();
                resultStack.push(second);
                resultStack.push(first);
            }
        }

        return resultStack;
    }

    public static void printStack(MidStack st) {
        MidStack tempStack = new MidStack();
        System.out.print("Stack (top to bottom): ");

        // Move elements to tempStack to access them in order
        while (!st.isEmpty()) {
            tempStack.push(st.pop());
        }

        // Print and restore elements back to the original stack
        boolean first = true;
        while (!tempStack.isEmpty()) {
            int elem = tempStack.pop();
            if (first) {
                System.out.print(elem + "(Top) ");
                first = false;
            } else {
                System.out.print("→ " + elem + " ");
            }
            st.push(elem);
        }

        System.out.println();
    }

    public static void main(String[] args) {
        // Test Case 1
        System.out.println("Test Case 1");
        MidStack st1 = new MidStack();
        for (int element : new int[]{8, 7, 6, 5, 4, 3, 2, 1}) {  // Push elements to stack
            st1.push(element);
        }
        System.out.println("Original Stack:");
        printStack(st1);
        MidStack result1 = doAdjacentSwap(st1);
        System.out.println("Modified Stack:");
        printStack(result1);
        System.out.println();

        // Test Case 2
        System.out.println("Test Case 2");
        MidStack st2 = new MidStack();
        for (int element : new int[]{7, 6, 5, 4, 3, 2, 1}) {  // Push elements to stack
            st2.push(element);
        }
        System.out.println("Original Stack:");
        printStack(st2);
        MidStack result2 = doAdjacentSwap(st2);
        System.out.println("Modified Stack:");
        printStack(result2);
    }
}
