public class Summer2024_Q1_MatrixRotation {

    // Method to rotate the matrix 90 degrees clockwise
    public static void rotate(int[][] matrix) {
        int n = matrix.length; // Dimension of the matrix (n x n)
        int lastPosition = n - 1;

        int i = 0;
        int j = lastPosition;

        while (true) {
            // Perform the rotation
            int temp = matrix[0][i];
            matrix[0][i] = matrix[i][lastPosition];
            matrix[i][lastPosition] = matrix[lastPosition][j];
            matrix[lastPosition][j] = matrix[j][0];
            matrix[j][0] = temp;

            // Move to the next set of indices
            i++;
            j--;

            // Break the loop when we reach the middle
            if (i == lastPosition && j == 0) {
                break;
            }
        }
    }

    // Utility method to print the matrix using regular for loop
    public static void printMatrix(int[][] matrix) {
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                System.out.print(matrix[i][j] + " | ");
            }
            System.out.println();
        }
    }

    // Main method to test the rotation
    public static void main(String[] args) {
        int[][] inputMatrix = {
            {1, 2, 3, 4, 5},
            {16, 17, 18, 19, 6},
            {15, 24, 25, 20, 7},
            {14, 23, 22, 21, 8},
            {13, 12, 11, 10, 9}
        };

        System.out.println("Before rotation:");
        printMatrix(inputMatrix);
        rotate(inputMatrix);
        System.out.println("After rotation:");
        printMatrix(inputMatrix);
        System.out.println("-".repeat(50));

        // Another test case: 4x4 matrix
        int[][] matrix2 = {
            {1, 2, 3, 4},
            {5, 6, 7, 8},
            {9, 10, 11, 12},
            {13, 14, 15, 16}
        };
        System.out.println("Original matrix:");
        printMatrix(matrix2);
        rotate(matrix2);
        System.out.println("After rotation:");
        printMatrix(matrix2);
        System.out.println("-".repeat(50));

        // Another test case: 3x3 matrix
        int[][] matrix3 = {
            {1, 2, 3},
            {4, 5, 6},
            {7, 8, 9}
        };
        System.out.println("Original matrix:");
        printMatrix(matrix3);
        rotate(matrix3);
        System.out.println("After rotation:");
        printMatrix(matrix3);
        System.out.println("-".repeat(50));
    }
}
