class Node {
    String elem;
    Node next;

    // Constructor to initialize the node
    public Node(String elem) {
        this.elem = elem;
        this.next = null;
    }
}

public class Sumemr2024_Final_Q2TokenRearrangement {

    // Function to return the node at the given index (1-based index)
    public static Node nodeAt(Node head, int index) {
        Node current = head;
        int count = 1;  // Start counting from position 1
        while (current != null) {
            if (count == index) {
                return current;
            }
            current = current.next;
            count++;
        }
        return null;  // Return null if index is out of bounds
    }

    // Function to rearrange tokens such that senior citizens come first
    public static Node rearrangeTokens(Node head, int seniorPos) {
        // Handle invalid seniorPos (if less than 1)
        if (seniorPos < 1) {
            return head;  // Return the original list if the position is invalid
        }

        // Get the non-senior end node (node at position seniorPos - 1)
        Node nonSeniorEndNode = nodeAt(head, seniorPos - 1);

        // If nonSeniorEndNode is null, it means the list is too short or seniorPos is invalid
        if (nonSeniorEndNode == null) {
            return head;
        }

        // Get the start node of the senior citizens (node at position seniorPos)
        Node seniorStartNode = nonSeniorEndNode.next;

        // If seniorStartNode is null, it means there are no senior tokens
        if (seniorStartNode == null) {
            return head;
        }

        // Find the last node in the senior citizen section
        Node current = seniorStartNode;
        while (current.next != null) {
            current = current.next;
        }
        Node seniorEndNode = current;

        // Rearrange the list
        seniorEndNode.next = head;  // Connect the last senior node to the start of the non-senior list
        nonSeniorEndNode.next = null;  // End the non-senior list
        head = seniorStartNode;  // Update head to point to the senior citizen section

        return head;  // Return the new head of the rearranged linked list
    }

    // Utility function to print the linked list for visualization
    public static void printLinkedList(Node head) {
        Node current = head;
        while (current != null) {
            System.out.print(current.elem);
            if (current.next != null) {
                System.out.print(" → ");
            }
            current = current.next;
        }
        System.out.println(" → None");
    }

    // Utility function to create a linked list from an array of elements
    public static Node createLinkedList(String[] elements) {
        if (elements == null || elements.length == 0) {
            return null;
        }
        Node head = new Node(elements[0]);
        Node current = head;
        for (int i = 1; i < elements.length; i++) {
            current.next = new Node(elements[i]);
            current = current.next;
        }
        return head;
    }

    public static void main(String[] args) {
        // First test case: Create the linked list A3 → A9 → A4 → A2 → A7 → A8 → A1
        String[] elements = {"A3", "A9", "A4", "A2", "A7", "A8", "A1"};
        Node head = createLinkedList(elements);

        // Print the original list
        System.out.println("Original Tokens List:");
        printLinkedList(head);

        // Set senior position to 4 (i.e., senior citizens start at position 4)
        int seniorPos = 4;
        System.out.println("\nRearranging tokens with senior citizens starting at position " + seniorPos + "...");
        head = rearrangeTokens(head, seniorPos);  // Call the rearrange function

        System.out.println("\nRearranged Tokens List:");
        printLinkedList(head);  // Print the rearranged list

        System.out.println("-".repeat(50));

        // Second test case: Create the linked list A9 → A3 → A4 → A8 → A6 → A5
        String[] elements2 = {"A9", "A3", "A4", "A8", "A6", "A5"};
        Node head2 = createLinkedList(elements2);

        // Print the original list
        System.out.println("Original Tokens List:");
        printLinkedList(head2);

        // Set senior position to 5 (i.e., senior citizens start at position 5)
        int seniorPos2 = 5;
        System.out.println("\nRearranging tokens with senior citizens starting at position " + seniorPos2 + "...");
        head2 = rearrangeTokens(head2, seniorPos2);  // Call the rearrange function

        System.out.println("\nRearranged Tokens List:");
        printLinkedList(head2);  // Print the rearranged list
    }
}
