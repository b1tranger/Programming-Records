class Node {
    int elem;
    Node next;

    // Constructor to initialize the node
    public Node(int elem) {
        this.elem = elem;
        this.next = null;
    }
}

public class Fall2023_final_Q2 {

    // Helper function to create a linked list from an array of elements
    public static Node createLinkedList(int[] elements) {
        if (elements.length == 0) {
            return null;
        }
        Node head = new Node(elements[0]);
        Node current = head;
        for (int i = 1; i < elements.length; i++) {
            current.next = new Node(elements[i]);
            current = current.next;
        }
        return head;
    }

    // Helper function to print the linked list
    public static void printList(Node head) {
        Node current = head;
        while (current != null) {
            if (current.next != null) {
                System.out.print(current.elem + " -> ");
            } else {
                System.out.print(current.elem);
            }
            current = current.next;
        }
        System.out.println();
    }

    // Function to return the node at the given index in the linked list
    public static Node nodeAt(Node head, int index) {
        Node current = head;
        int count = 0;

        // Traverse the linked list until the desired index or end of the list
        while (current != null) {
            if (count == index) {
                return current;
            }
            current = current.next;
            count++;
        }

        // If index is out of bounds, return null
        return null;
    }

    // Function to calculate the sum of elements at the specified distances
    public static int sumDist2(Node head, int[] dist) {
        int totalSum = 0;

        // Iterate over each distance in the array
        for (int i = 0; i < dist.length; i++) {
            // Get the node at the given distance using nodeAt
            Node node = nodeAt(head, dist[i]);

            // Add the value of the node at the distance or 0 if it doesn't exist
            if (node == null) {
                totalSum += 0;
            } else {
                totalSum += node.elem;
            }
        }

        return totalSum;
    }

    public static void main(String[] args) {
        // Creating the linked list: 10 -> 16 -> -5 -> 9 -> 3 -> 4
        int[] elements = {10, 16, -5, 9, 3, 4};
        Node head = createLinkedList(elements);

        // Print the original linked list
        System.out.println("Original Linked List:");
        printList(head);

        // Array of distances
        int[] dist = {2, 0, 5, 2, 8};

        // Calling the function to get the sum
        System.out.println("Sum of elements at specified distances:");
        System.out.println(sumDist2(head, dist));  // Output: 4
    }
}
