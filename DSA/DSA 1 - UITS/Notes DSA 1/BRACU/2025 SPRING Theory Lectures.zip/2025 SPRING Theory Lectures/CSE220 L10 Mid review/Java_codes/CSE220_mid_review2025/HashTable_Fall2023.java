class HNode {
    String key;
    String value;
    HNode next;

    public HNode(String key, String value, HNode next) {
        this.key = key;
        this.value = value;
        this.next = next;
    }
}

public class HashTable_Fall2023 {
    
    // Hash function to calculate the index
    public static int check(String key) {
        int v = 0;
        for (int i = 0; i < key.length(); i++) {
            char c = key.charAt(i);
            if (Character.isDigit(c)) {
                v += Character.getNumericValue(c);
            } else {
                v += (int) c;
            }
        }
        return v % 3;
    }

    // Insert a key-value pair into the hash table
    public static void insert(HNode[] hashTable, String key, String value) {
        int index = check(key);
        
        // Create a dummy head node if the bucket is empty
        if (hashTable[index] == null) {
            hashTable[index] = new HNode(null, null, null);  // Dummy head node
        }

        // Prepend after dummy head
        HNode newNode = new HNode(key, value, null);
        HNode predecessor = hashTable[index];  // Predecessor is the dummy head
        HNode successor = predecessor.next;

        newNode.next = successor;  // Link the successor
        predecessor.next = newNode;  // Link the predecessor
    }

    // Print the hash table
    public static void printHashTable(HNode[] hashTable) {
        int i = 0;  // Manual index tracking
        for (HNode node : hashTable) {
            System.out.print(i + ": ");
            HNode current = node;
            while (current != null && current.next != null) {
                System.out.print("(" + current.next.key + ", " + current.next.value + ") → ");
                current = current.next;
            }
            System.out.println("None");  // End of the linked list
            i++;  // Increment the index
        }
        System.out.println();
    }

    // Remove a key from the hash table
    public static void remove(HNode[] hashTable, String remKey) {
        int index = check(remKey);  // Calculate the hash index

        HNode predecessor = hashTable[index];  // Start at the dummy head
        HNode currentNode = predecessor.next;  // Start after dummy head

        // Traverse the chain to find the node to remove
        while (currentNode != null) {
            if (currentNode.key.equals(remKey)) {
                // Bypass the node to remove it
                HNode successor = currentNode.next;
                predecessor.next = successor;
                System.out.println("Removed (" + currentNode.key + ", " + currentNode.value + ")");
                return;
            }
            predecessor = currentNode;
            currentNode = currentNode.next;
        }
    }

    public static void main(String[] args) {
        // Initialize the hash table
        int size = 3;
        HNode[] hashTable = new HNode[size];

        // Insert data using a regular loop
        String[][] keyValPairs = {
            {"13D", "ZMD"}, {"10A", "ABW"},
            {"31B", "NZF"},
            {"2A4", "RAK"}, {"C7B", "FAF"}, {"1A2", "MNY"}
        };

        for (int i = 0; i < keyValPairs.length; i++) {
            insert(hashTable, keyValPairs[i][0], keyValPairs[i][1]);
        }

        // Print the original hash table
        System.out.println("Original table before remove:");
        printHashTable(hashTable);

        // Remove a key
        String keyToRemove = "C7B";
        remove(hashTable, keyToRemove);

        // Print the modified hash table
        System.out.println("Modified table after remove:");
        printHashTable(hashTable);
    }
}
