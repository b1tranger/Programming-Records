class CNode {
    int[] data;
    CNode next;

    public CNode(int[] data) {
        this.data = data;
        this.next = null;
    }
}

class CStack {
    private CNode top;
    private int size;

    public CStack() {
        this.top = null;
        this.size = 0;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public void push(int[] data) {
        CNode newCNode = new CNode(data);
        newCNode.next = top;
        top = newCNode;
        size++;
    }

    public int[] pop() {
        if (isEmpty()) {
            throw new RuntimeException("Underflow: Pop from empty CStack");
        }
        int[] data = top.data;
        top = top.next;
        size--;
        return data;
    }

    public int[] peek() {
        if (isEmpty()) {
            throw new RuntimeException("Underflow: Peek from empty CStack");
        }
        return top.data;
    }
}

public class OverlappingTasks {
    // Fall2024: Overlapping tasks
    public static void printTotalTask(int[][] tasks) {
        CStack mergedStack = new CStack();

        for (int i = 0; i < tasks.length; i++) {
            int start = tasks[i][0];
            int end = tasks[i][1];

            // If the CStack is empty or there's no overlap, push the new task
            if (mergedStack.isEmpty() || mergedStack.peek()[1] < start) {
                mergedStack.push(new int[]{start, end});
            } else {
                // Merge with the top task if there's an overlap
                int[] topTask = mergedStack.pop();
                mergedStack.push(new int[]{topTask[0], Math.max(topTask[1], end)});
            }
        }

        while (!mergedStack.isEmpty()) {
            int[] task = mergedStack.pop();
            System.out.println(task[0] + ", " + task[1]);
        }
    }

    public static void main(String[] args) {
        // Fall2024: Overlapping tasks
        System.out.println("// Fall2024: Overlapping tasks");
        int[][] tasks = {
            {1, 5},
            {2, 3},
            {4, 6},
            {7, 10},
            {9, 11},
            {12, 15}
        };

        printTotalTask(tasks);
    }
}
