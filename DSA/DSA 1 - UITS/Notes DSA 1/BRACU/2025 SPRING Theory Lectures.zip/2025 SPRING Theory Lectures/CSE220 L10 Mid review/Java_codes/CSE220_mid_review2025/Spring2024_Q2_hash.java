class Node {
    char elem;
    Node next;

    public Node(char elem, Node next) {
        this.elem = elem;
        this.next = next;
    }
}

public class Spring2024_Q2_hash {
    public static int hash(Node list, String st) {
        int totalSum = 0;

        // Traverse the linked list
        Node current = list; // taking the head of the LL
        while (current != null) {
            char character = current.elem;
            int index = -1; // Default to -1 if not found

            // Loop through the string from the end to find the last occurrence
            for (int i = st.length() - 1; i >= 0; i--) {
                if (st.charAt(i) == character) {
                    index = i;
                    break;
                }
            }

            totalSum += index;
            current = current.next;
        }

        // Return the sum modulo 10
        return totalSum % 10;
    }

    public static void main(String[] args) {
        // Sample linked list: D → A → T → A
        Node listHead = new Node('D', new Node('A', new Node('T', new Node('A', null))));

        // Sample string
        String st = "SADA";

        // Call the hash function
        int result = hash(listHead, st);

        // Print the result
        System.out.println(result);
    }
}
