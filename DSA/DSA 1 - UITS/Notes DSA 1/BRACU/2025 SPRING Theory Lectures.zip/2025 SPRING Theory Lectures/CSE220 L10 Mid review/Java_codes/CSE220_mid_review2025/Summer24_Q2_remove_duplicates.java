class Node {
    int elem;
    Node next;

    // Constructor to initialize the node
    public Node(int elem) {
        this.elem = elem;
        this.next = null;
    }
}

public class Summer24_Q2_remove_duplicates {

    // Helper function to create a linked list from an array of elements
    public static Node createLinkedList(int[] elements) {
        if (elements.length == 0) {
            return null;
        }
        Node head = new Node(elements[0]);
        Node current = head;
        for (int i = 1; i < elements.length; i++) {
            current.next = new Node(elements[i]);
            current = current.next;
        }
        return head;
    }

    // Function to print the linked list
    public static void printList(Node head) {
        Node current = head;
        while (current != null) {
            if (current.next != null) {
                System.out.print(current.elem + " -> ");
            } else {
                System.out.print(current.elem);
            }
            current = current.next;
        }
        System.out.println();
    }

    // Function to remove duplicates from the linked list
    public static Node removeDuplicates(Node head) {
        Node current = head;

        // Traverse through the list
        while (current != null) {
            Node runner = current;
            // Compare the current node with all subsequent nodes
            while (runner.next != null) {
                if (runner.next.elem == current.elem) {
                    // Remove the duplicate node
                    runner.next = runner.next.next;
                } else {
                    runner = runner.next;
                }
            }
            current = current.next;
        }

        return head;
    }

    public static void main(String[] args) {
        // Test Case 1: Create linked list 101 -> 103 -> 101 -> 102 -> 103 -> 104 -> 105 -> 105
        int[] elements1 = {101, 103, 101, 102, 103, 104, 105, 105};
        Node head1 = createLinkedList(elements1);

        // Print original list
        System.out.println("Original Tickets (Test Case 1):");
        printList(head1);

        // Remove duplicates
        head1 = removeDuplicates(head1);

        // Print fixed list
        System.out.println("Fixed Tickets (Test Case 1 - Duplicates removed):");
        printList(head1);

        // Test Case 2: Create linked list 102 -> 101 -> 101 -> 102 -> 102 -> 102 -> 103 -> 104 -> 104
        int[] elements2 = {102, 101, 101, 102, 102, 102, 103, 104, 104};
        Node head2 = createLinkedList(elements2);

        // Print original list
        System.out.println("\nOriginal Tickets (Test Case 2):");
        printList(head2);

        // Remove duplicates
        head2 = removeDuplicates(head2);

        // Print fixed list
        System.out.println("Fixed Tickets (Test Case 2 - Duplicates removed):");
        printList(head2);
    }
}
