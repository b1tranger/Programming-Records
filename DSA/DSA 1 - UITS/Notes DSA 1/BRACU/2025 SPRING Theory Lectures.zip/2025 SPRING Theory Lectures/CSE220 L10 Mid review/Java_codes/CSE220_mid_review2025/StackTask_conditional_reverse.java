class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class Stack {
    private Node top;
    private int size;

    public Stack() {
        this.top = null;
        this.size = 0;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public void push(int data) {
        Node newNode = new Node(data);
        newNode.next = top;
        top = newNode;
        size++;
    }

    public int pop() {
        if (isEmpty()) {
            throw new RuntimeException("Underflow: Pop from empty stack");
        }
        int data = top.data;
        top = top.next;
        size--;
        return data;
    }

    public int peek() {
        if (isEmpty()) {
            throw new RuntimeException("Underflow: Peek from empty stack");
        }
        return top.data;
    }
}

public class StackTask_conditional_reverse {
    
    public static Stack conditionalReverse(Stack stack) {
        Stack resultStack = new Stack();
        Integer lastPushed = null;

        while (!stack.isEmpty()) {
            int current = stack.pop();
            if (lastPushed == null || current != lastPushed) {
                resultStack.push(current);
                lastPushed = current;
            }
        }
        return resultStack;
    }
    

    // Helper function---not part of mid solution
    public static void printStack(Stack stack) {
        Stack tempStack = new Stack();
        while (!stack.isEmpty()) {
            tempStack.push(stack.pop());
        }
        while (!tempStack.isEmpty()) {
            int elem = tempStack.pop();
            System.out.print(elem + " ");
            stack.push(elem);
        }
        System.out.println();
    }
    



    public static void main(String[] args) {
 
        // Fall23- Q3 (2): conditional_reverse
        System.out.println("Fall23- Q3 (2): conditional_reverse");
        Stack stack = new Stack();
        stack.push(10);
        stack.push(10);
        stack.push(20);
        stack.push(20);
        stack.push(30);
        stack.push(10);
        stack.push(50);

        System.out.println("Original Stack (Top to Bottom): ");
        printStack(stack);

        Stack resultStack = conditionalReverse(stack);
        System.out.print("Returned Stack (Top to Bottom): ");
        printStack(resultStack);
        System.out.println("--------------------------------------");
        ///////////////////////////////////////////////////////
        
        ///////////////////////////////////////////////////////
        System.out.println("--------------------------------------");
        ///////////////////////////////////////////////////////        
    }
}