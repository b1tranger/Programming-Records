class Node {
    int data;   // Data stored in the node
    Node next;  // Pointer to the next node

    // Constructor
    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}