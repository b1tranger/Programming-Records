public class ReverseWord {

    // Function to reverse a word using ListStack
    public static String reverseWord(String word) {
        ListStack stack = new ListStack();

        // Push each character of the word onto the stack using a regular for loop
        for (int i = 0; i < word.length(); i++) {
            stack.push((int) word.charAt(i)); // Cast char to int for compatibility with ListStack
        }

        // Pop characters from the stack to form the reversed word
        StringBuilder reversedWord = new StringBuilder();
        while (!stack.isEmpty()) {
            reversedWord.append((char) stack.pop()); // Cast int back to char
        }

        return reversedWord.toString();
    }

    public static void main(String[] args) {
        // Example 1
        String word1 = "hello";
        System.out.println("Original word: " + word1);
        System.out.println("Reversed word: " + reverseWord(word1));
        System.out.println("-".repeat(20));

        // Example 2
        String word2 = "CSE220";
        System.out.println("Original word: " + word2);
        System.out.println("Reversed word: " + reverseWord(word2));
    }
}