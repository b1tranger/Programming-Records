public class Node {
    int elem;
    Node next;
    Node prev;

    public Node(int elem) {
        this.elem = elem;
        this.next = null;
        this.prev = null;
    }
}
