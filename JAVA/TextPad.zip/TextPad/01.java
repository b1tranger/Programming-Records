class Test{

	}
	class Main{
		public static void main(System args[]){


		}


		}